package com.xl.utils;

public interface ILock {
    boolean tryLock(long timeoutSec);
    void unLock();
}
