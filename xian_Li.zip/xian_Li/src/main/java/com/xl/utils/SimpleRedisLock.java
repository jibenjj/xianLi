package com.xl.utils;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;

import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class SimpleRedisLock implements ILock{
    private StringRedisTemplate stringRedisTemplate;
    private String name;
    private static final String key_prefix = "lock:";
    private static final String ID_prefix = UUID.randomUUID().toString()+"-";

//    private static final DefaultRedisScript<Long> UNLOCK_SCRIPT;
//    static {
//        UNLOCK_SCRIPT=new DefaultRedisScript<>();
//        UNLOCK_SCRIPT.setLocation(new ClassPathResource("unlock.lua"));
//        UNLOCK_SCRIPT.setResultType(Long.class);
//    }
    public SimpleRedisLock( String name,StringRedisTemplate stringRedisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
        this.name = name;
    }
    @Override
    public boolean tryLock(long timeoutSec) {
        String threadId =ID_prefix + Thread.currentThread().getId();
        String key = key_prefix + name;
        Boolean success = stringRedisTemplate.opsForValue().setIfAbsent(key, threadId, timeoutSec, TimeUnit.SECONDS);
        return Boolean.TRUE.equals(success);
    }

//    @Override
//    public void unLock() {
//        stringRedisTemplate.execute(UNLOCK_SCRIPT, Collections.singletonList(key_prefix + name),ID_prefix + Thread.currentThread().getId());
//    }


    @Override
    public void unLock() {
        String script=
                "if(redis.call('get',KEYS[1])==ARGV[1])then\n" +
                        "    return redis.call('del',KEYS[1])\n" +
                        "else \n" +
                        "    return 0\n" +
                        "end";
        String id = stringRedisTemplate.opsForValue().get(key_prefix + name);
        String threadId =ID_prefix + Thread.currentThread().getId();
        stringRedisTemplate.execute(new DefaultRedisScript<>(script,Boolean.class), Collections.singletonList(key_prefix + name),threadId);
    }

//    @Override
//    public void unLock() {
//        String threadId =ID_prefix + Thread.currentThread().getId();
//        String id = stringRedisTemplate.opsForValue().get(key_prefix + name);
//        if(threadId.equals(id)) {
//
//            stringRedisTemplate.delete(key_prefix + name);
//        }
//    }
}
