package com.xl.service.impl;

import cn.hutool.json.JSONUtil;
import com.xl.dto.Result;
import com.xl.entity.SeckillVoucher;
import com.xl.entity.VoucherOrder;
import com.xl.mapper.VoucherOrderMapper;
import com.xl.service.ISeckillVoucherService;
import com.xl.service.IVoucherOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xl.utils.*;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.concurrent.*;

@Service
    public class VoucherOrderServiceImpl extends ServiceImpl<VoucherOrderMapper, VoucherOrder> implements IVoucherOrderService {
    @Resource
    private ISeckillVoucherService seckillVoucherService;
    @Resource
    private RedisIdWorker redisIdWorker;
    @Resource
    private StringRedisTemplate stringRedisTemplate;
    @Resource
    RedissonClient redissonClient;
    @Resource
    CacheClient cacheClient;

//    private BlockingQueue<VoucherOrder> orderTasks=new ArrayBlockingQueue<VoucherOrder>(1024*1024);
//    private static final ExecutorService SECKILL_ORDER_EXECUTOR = Executors.newSingleThreadExecutor();
//    @PostConstruct
//    private void init(){
//        SECKILL_ORDER_EXECUTOR.submit(new VoucherOrderHandler());
//    }
//
//    private class VoucherOrderHandler implements  Runnable{
//        @Override
//        public void run() {
//            while(true){
//                try {
//                    VoucherOrder voucherOrder = orderTasks.take();
//                    handlerVoucherOrder(voucherOrder);
//                } catch (InterruptedException e) {
//                    log.error("订单异常",e);
//                }
//            }
//        }
//
//
//    }

//    private void handlerVoucherOrder(VoucherOrder voucherOrder) {
//        Long userId = voucherOrder.getUserId();
//        RLock orderLock = redissonClient.getLock("voucher:" + voucherId);
//        boolean isLock=orderLock.tryLock(10,10,TimeUnit.SECONDS);
////        while(!orderLock.tryLock())
////            {
////                Thread.sleep(50);
////            }
//        if(!isLock){
//            log.error("不允许重复下单");
//            return ;
//        }
//        try {
//
//            if (Boolean.TRUE.equals(stringRedisTemplate.hasKey("cache:order:"+"user:"+userId+"_good:"+voucherId))) {
//                return Result.fail("一人限购一单");
//            }
//            //再次取出对象判断是否能进行库存扣减操作
//            json = stringRedisTemplate.opsForValue().get(key);
//            voucher=JSONUtil.toBean(json, SeckillVoucher.class);
//            //库存不足
//            if(voucher.getStock()<1){
//                return Result.fail("库存不足！");
//            }
//            //库存充足，库存减一之后回写redis
//            voucher.setStock(voucher.getStock()-1);
//            json=JSONUtil.toJsonStr(voucher);
//            stringRedisTemplate.opsForValue().set(key, json);
//            //TODO 异步回写尚未完成
//            seckillVoucherService.update().setSql("stock=stock-1").eq("voucher_id", voucherId).gt("stock",0).update();
//            //TODO 订单创建 应该通知MQ
//            // 注意自调用，应使用代理对象
//            return creatVoucherOrder(voucherId);
//
//
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }finally {
//            orderLock.unlock();
//        }
//    }

    @Override
    public Result seckillVoucher(Long voucherId) throws InterruptedException {

        String key="cache:secKillVoucher:"+voucherId;
        String json = stringRedisTemplate.opsForValue().get(key);
        Long userId = UserHolder.getUser().getId();

        SeckillVoucher voucher = JSONUtil.toBean(json, SeckillVoucher.class);
        if (voucher.getBeginTime().isAfter(LocalDateTime.now())) {
            return Result.fail("秒杀尚未开始！");
        }
        if (voucher.getEndTime().isBefore(LocalDateTime.now())) {
            return Result.fail("秒杀已经结束！");
        }
        if (voucher.getStock()<1) {
            return Result.fail("库存不足！");
        }



        RLock orderLock = redissonClient.getLock("voucher:" + voucherId);
        boolean isLock=orderLock.tryLock(10,10,TimeUnit.SECONDS);
//        while(!orderLock.tryLock())
//            {
//                Thread.sleep(50);
//            }
        if(!isLock){
            return Result.fail("不可重复下单！");
        }
            try {

                if (Boolean.TRUE.equals(stringRedisTemplate.hasKey("cache:order:"+"user:"+userId+"_good:"+voucherId))) {
                    return Result.fail("一人限购一单");
                }
                //再次取出对象判断是否能进行库存扣减操作
                json = stringRedisTemplate.opsForValue().get(key);
                voucher=JSONUtil.toBean(json, SeckillVoucher.class);
                //库存不足
                if(voucher.getStock()<1){
                    return Result.fail("库存不足！");
                }
                //库存充足，库存减一之后回写redis
                voucher.setStock(voucher.getStock()-1);
                json=JSONUtil.toJsonStr(voucher);
                stringRedisTemplate.opsForValue().set(key, json);
                //TODO 异步回写尚未完成
                //orderTasks.add(voucherOrder);

                seckillVoucherService.update().setSql("stock=stock-1").eq("voucher_id", voucherId).gt("stock",0).update();
                //TODO 订单创建 应该通知MQ
                // 注意自调用，应使用代理对象
                return creatVoucherOrder(voucherId);


            } catch (Exception e) {
                throw new RuntimeException(e);
            }finally {
                orderLock.unlock();
            }
    }
    @Transactional
    public  Result creatVoucherOrder(Long voucherId){
            Long userId = UserHolder.getUser().getId();
            VoucherOrder voucherOrder = new VoucherOrder();
            long orderId = redisIdWorker.nextId("order");
            voucherOrder.setId(orderId);
            voucherOrder.setUserId(userId);
            voucherOrder.setVoucherId(voucherId);
            save(voucherOrder);
            String json = "cache:order:"+"user:"+userId+"_good:"+voucherId;
            SeckillVoucher seckillVoucher = seckillVoucherService.getById(voucherId);
            Duration duration = Duration.between(LocalDateTime.now(), seckillVoucher.getEndTime());
            long ttl = duration.getSeconds()+10L;
            stringRedisTemplate.opsForValue().set(json,"",ttl,TimeUnit.SECONDS);
            return Result.ok(orderId);
        }



}
