package com.xl.service.impl;

import com.xl.dto.Result;
import com.xl.entity.ShopType;
import com.xl.mapper.ShopTypeMapper;
import com.xl.service.IShopTypeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.xl.utils.RedisConstants.SHOP_TYPE_KEY;


/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Service
public class ShopTypeServiceImpl extends ServiceImpl<ShopTypeMapper, ShopType> implements IShopTypeService {

    @Resource
    private StringRedisTemplate stringRedisTemplate;
    @Override
    public Result queryTypeList() {
        //1.先访问redis
        Set<String> typeSet = stringRedisTemplate.opsForZSet().range(SHOP_TYPE_KEY, 0, -1);
        //2.是否存在于redis
        assert typeSet != null;
        if(!typeSet.isEmpty()){
            //2.1存在redis当中
            List<ShopType>  typeList =  creatTypeList(typeSet);
             return Result.ok(typeList);
        }

        //2.2找不到去sql找
        List<ShopType> typeList = query().orderByAsc("sort").list();
        //3.1sql找不到
        if(typeList.isEmpty())
        {
            return Result.fail("店铺不存在");
        }
        //3.2sql找到了，回写redis
        typeList.forEach(shopType -> {
            // 构造 Redis List 的 key

            int score=shopType.getSort();
            // 构造 Redis List 的 value
            String value = shopType.getId()+","+shopType.getName() + "," + shopType.getIcon();

            // 将 value 写入 Redis Lists
            stringRedisTemplate.opsForZSet().add(SHOP_TYPE_KEY,value,score);
        });

        return Result.ok(typeList);
    }

    List<ShopType> creatTypeList(Set<String> typeListSet)
    {
        return   typeListSet.stream()
                .map(member -> {
                    // 解析成员字符串
                    String[] parts = member.split(",");
                    Long id = Long.parseLong(parts[0]);
                    String name = parts[1];
                    String icon = parts[2];

                    // 创建 ShopType 对象
                    ShopType shopType = new ShopType();
                    shopType.setId(id);
                    shopType.setName(name);
                    shopType.setIcon(icon);

                    return shopType;
                }).collect(Collectors.toList());
    }



}


