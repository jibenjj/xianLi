package com.xl.service.impl;

import cn.hutool.json.JSONUtil;
import com.xl.entity.SeckillVoucher;
import com.xl.entity.Voucher;
import com.xl.mapper.SeckillVoucherMapper;
import com.xl.service.ISeckillVoucherService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xl.service.IVoucherService;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.Resource;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;


/**
 * <p>
 * 秒杀优惠券表，与优惠券是一对一关系 服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2022-01-04
 */
@Service
public class SeckillVoucherServiceImpl extends ServiceImpl<SeckillVoucherMapper, SeckillVoucher> implements ISeckillVoucherService {

    @Resource
    private StringRedisTemplate stringRedisTemplate;
    @Resource
    private IVoucherService voucherService;
    @Override
    @Transactional
    public void addSecKillVoucher(Voucher voucher) {
        voucherService.save(voucher);
        SeckillVoucher seckillVoucher = new SeckillVoucher();
        seckillVoucher.setVoucherId(voucher.getId());
        seckillVoucher.setStock(voucher.getStock());
        seckillVoucher.setBeginTime(voucher.getBeginTime());
        seckillVoucher.setEndTime(voucher.getEndTime());
        save(seckillVoucher);
        SeckillVoucher seckillVoucher1 = getById(voucher.getId());
        String json= JSONUtil.toJsonStr(seckillVoucher1);
        String key="cache:secKillVoucher:"+seckillVoucher1.getVoucherId();
        Duration duration = Duration.between(LocalDateTime.now(), seckillVoucher1.getEndTime());
        long ttl = duration.getSeconds()+10L;
        stringRedisTemplate.opsForValue().set(key,json,ttl, TimeUnit.SECONDS);
    }

}
