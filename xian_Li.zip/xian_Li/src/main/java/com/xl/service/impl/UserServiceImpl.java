package com.xl.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.lang.UUID;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.xl.dto.LoginFormDTO;
import com.xl.dto.Result;
import com.xl.dto.UserDTO;
import com.xl.entity.User;
import com.xl.mapper.UserMapper;
import com.xl.service.IUserService;
import com.xl.utils.RegexUtils;
import com.xl.utils.UserHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.connection.BitFieldSubCommands;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.xl.utils.RedisConstants.*;
import static com.xl.utils.SystemConstants.USER_NICK_NAME_PREFIX;

@Slf4j
@Service

public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    @Resource
    private StringRedisTemplate stringRedisTemplate;


    @Override
    public Result sendCode(String phone, HttpSession session) {
        //1.校验手机号的格式是否正确，调用的工具类包utils下的的正则表达式包
        if (RegexUtils.isPhoneInvalid(phone)) {
            //2.格式有问题
            return Result.fail("手机号格式错误");
        }
        //3.格式正确，生成验证码，调用utils包下的随机数生成函数，一共6位
        String code = RandomUtil.randomNumbers(6);
        //4.保存到redis
        stringRedisTemplate.opsForValue().set(LOGIN_CODE_KEY+phone,code,LOGIN_CODE_TTL, TimeUnit.MINUTES);
        //5.发送验证码,尚未完成！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
        log.debug("发送验证码成功，验证码：{}",code);
        //6.返回ok
        return Result.ok();
    }


    @Override
    public Result login(LoginFormDTO loginForm, HttpSession session) {
        //1.校验手机号格式，因为点击发送验证码和点击登录，是两条不同的请求，考虑以下情况，用户使用正确的手机号获取验证码，然后修改手机号并且填写验证码然后点击登录，所以要做独立的校验
        String phone=loginForm.getPhone();
        if (RegexUtils.isPhoneInvalid(phone)) {
            //1.2.格式错误
            return Result.fail("手机号格式错误");
        }
        //2.校验验证码
        //2.1从redis当中取出在获取验证码时所发送的code
        String cacheCode = stringRedisTemplate.opsForValue().get(LOGIN_CODE_KEY+phone);
        //2.2从前端用户点击登录时传入的code
        String code = loginForm.getCode();
        //2.3判断两个code是否一致
        if(cacheCode==null||!cacheCode.equals(code))
        {
            //3.不一致
            return  Result.fail("验证码错误");
        }
        //4.一致，根据手机号查询用户
        User user = query().eq("phone", phone).one();
        //5.判断用户是否存在
        if(user==null){
            //6.不存在，创建新用户
            user = createUserWithPhone(phone);
        }
        //随机生成token令牌
        String token = UUID.randomUUID().toString(true);
        //通过工具类把user转成dto
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        //通过工具类把dto转成map用于存储到redis的hash结构中
        Map<String, Object> userMap = BeanUtil.beanToMap(userDTO,new HashMap<>(),
                CopyOptions.create().setFieldValueEditor((fieldName,fieldValue) -> fieldValue.toString()));
        stringRedisTemplate.opsForHash().putAll(LOGIN_USER_KEY+token,userMap);
        stringRedisTemplate.expire(LOGIN_USER_KEY+token,LOGIN_USER_TTL, TimeUnit.MINUTES);
        //7.保存信息到session
        return Result.ok(token);
    }

    @Override
    public Result sign() {
        Long userId= UserHolder.getUser().getId();
        LocalDateTime now = LocalDateTime.now();
        String keySuffix = now.format(DateTimeFormatter.ofPattern(":yyyyMM"));
        String key=USER_SIGN_KEY+userId+keySuffix;
        int dayOfMonth = now.getDayOfMonth();
        stringRedisTemplate.opsForValue().setBit(key,dayOfMonth-1,true);
        return Result.ok();
    }

    @Override
    public Result signCount() {
        Long userId= UserHolder.getUser().getId();
        LocalDateTime now = LocalDateTime.now();
        String keySuffix = now.format(DateTimeFormatter.ofPattern(":yyyyMM"));
        String key=USER_SIGN_KEY+userId+keySuffix;
        int dayOfMonth = now.getDayOfMonth();
        List<Long> result = stringRedisTemplate.opsForValue().bitField(key, BitFieldSubCommands.create().get(BitFieldSubCommands.BitFieldType.unsigned(dayOfMonth)).valueAt(0));
        if(result==null||result.isEmpty()){
            return Result.ok(0);
        }
        Long num = result.get(0);
        if(num==null||num==0){
            return Result.ok(0);
        }
        int count=0;
        while(true){
            if ((num&1)==0) {
                break;
            }else{
                count++;
            }
            num>>>=1;
        }
        return Result.ok(count);
    }

    private User createUserWithPhone(String phone) {
        User user = new User();
        user.setPhone(phone);
        user.setNickName(USER_NICK_NAME_PREFIX +RandomUtil.randomString(10));
        //使用mybatis保存到mysql
        save(user);
        return user;
    }
}

















